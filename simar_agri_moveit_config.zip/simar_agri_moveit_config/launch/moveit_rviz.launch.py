from launch_ros.actions import SetParameter
from moveit_configs_utils import MoveItConfigsBuilder
from moveit_configs_utils.launches import generate_moveit_rviz_launch

def generate_launch_description():
    moveit_config = MoveItConfigsBuilder("simar_agri", package_name="simar_agri_moveit_config").to_moveit_configs()

    ld = generate_moveit_rviz_launch(moveit_config)

    # Force use_sim_time globally for everything in this RViz launch file
    ld.add_action(SetParameter(name='use_sim_time', value=True))

    return ld
