from moveit_configs_utils import MoveItConfigsBuilder
from moveit_configs_utils.launches import generate_move_group_launch

def generate_launch_description():
    moveit_config = (
        MoveItConfigsBuilder("simar_agri", package_name="simar_agri_moveit_config")
        .robot_description(file_path="config/simar_agri.urdf.xacro")
        .to_moveit_configs()
    )

    # Force use_sim_time across all generated parameters
    config_dict = moveit_config.to_dict()
    config_dict["use_sim_time"] = True

    return generate_move_group_launch(moveit_config)
