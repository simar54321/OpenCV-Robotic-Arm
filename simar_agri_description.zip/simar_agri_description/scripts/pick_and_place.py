#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
from builtin_interfaces.msg import Duration
import time

class PickAndPlace(Node):
    def __init__(self):
        super().__init__('pick_and_place')
        self.set_parameters([rclpy.parameter.Parameter('use_sim_time', rclpy.Parameter.Type.BOOL, True)])

        self.arm_pub = self.create_publisher(JointTrajectory, '/arm_controller/joint_trajectory', 10)
        self.gripper_pub = self.create_publisher(JointTrajectory, '/gripper_controller/joint_trajectory', 10)
        time.sleep(1.0)

    def move_joints(self, base_rad, shoulder_rad, wrist_rad, duration_sec=2.0):
        self.get_logger().info(f'Executing -> Base: {base_rad}, Shoulder: {shoulder_rad}, Wrist: {wrist_rad}')
        traj = JointTrajectory()

        traj.header.stamp = self.get_clock().now().to_msg()
        traj.joint_names = ['joint_base', 'shoulder', 'wristmotion']

        point = JointTrajectoryPoint()
        point.positions = [float(base_rad), float(shoulder_rad), float(wrist_rad)]
        point.time_from_start = Duration(sec=int(duration_sec), nanosec=0)
        traj.points.append(point)

        self.arm_pub.publish(traj)
        time.sleep(duration_sec + 0.5)

    def move_gripper(self, open_gripper=True):
        self.get_logger().info('Opening Gripper...' if open_gripper else 'Closing Gripper...')
        traj = JointTrajectory()

        traj.header.stamp = self.get_clock().now().to_msg()
        traj.joint_names = ['joint_gripper1', 'joint_gripper2']
        point = JointTrajectoryPoint()

        # Swapped logic based on Gazebo physics
        if open_gripper:
            point.positions = [-0.004, 0.017]
        else:
            point.positions = [-0.043, 0.044]

        point.time_from_start = Duration(sec=1, nanosec=0)
        traj.points.append(point)
        self.gripper_pub.publish(traj)
        time.sleep(1.5)

def main(args=None):
    rclpy.init(args=args)
    node = PickAndPlace()

    # 1. Open grippers and face forward
    node.move_gripper(open_gripper=True)
    node.move_joints(-1.57, 0.0, 0.0)

    # 2. Reach down for the box
    node.move_joints(-1.57, -1.57, -0.0)

    # 3. Close grippers (Grab!)
    node.move_gripper(open_gripper=False)

    # 4. Lift the box up
    node.move_joints(-0.5, -0.2, 0.0)

    # 5. Swing base 90 degrees to the drop-off zone
    node.move_joints(1.57, -0.2, 0.0)

    # 6. Reach down and drop
    node.move_joints(1.57, -0.8, -0.5)
    node.move_gripper(open_gripper=True)

    # 7. Return to home position
    node.move_joints(0.0, 0.0, 0.0)

    node.get_logger().info('Pick and Place Complete!')
    rclpy.shutdown()

if __name__ == '__main__':
    main()
