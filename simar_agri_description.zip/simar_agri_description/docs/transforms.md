# Transformation Matrices - simar_agri

Homogeneous transformation matrices between consecutive frames.
Convention: URDF RPY (XYZ extrinsic / ZYX intrinsic).

## Notation

### Frames

| Index | Link |
|-------|------|
| $L_{0}$ | base_link |
| $L_{1}$ | cylider |
| $L_{2}$ | arm |
| $L_{3}$ | wrist |
| $L_{4}$ | gripper2 |
| $L_{5}$ | gripper1 |

### Joint Variables

| Variable | Joint | Type | From | To |
|----------|-------|------|------|----|
| $q_{1}$ | joint_base | continuous (rad) | $L_{0}$ | $L_{1}$ |
| $q_{2}$ | shoulder | continuous (rad) | $L_{1}$ | $L_{2}$ |
| $q_{3}$ | wristmotion | revolute (rad) | $L_{2}$ | $L_{3}$ |
| $q_{4}$ | joint_gripper1 | prismatic (m) | $L_{3}$ | $L_{4}$ |
| $q_{5}$ | joint_gripper2 | prismatic (m) | $L_{3}$ | $L_{5}$ |

Shorthand: $c_i = \cos(q_i)$, $s_i = \sin(q_i)$

### Kinematic Tree

```
L0: base_link
  +-- [continuous] joint_base (q1)
      L1: cylider
        +-- [continuous] shoulder (q2)
            L2: arm
              +-- [revolute] wristmotion (q3)
                  L3: wrist
                    |-- [prismatic] joint_gripper1 (q4)
                    |   L4: gripper2
                    +-- [prismatic] joint_gripper2 (q5)
                        L5: gripper1
```

## Transforms

## joint_base

$L_{0}$ **base_link** -> $L_{1}$ **cylider** (continuous)
  Variable: $q_{1}$

- **origin xyz**: (-0.053457, 0.044911, -0.022649) m
- **origin rpy**: (0, 0, -0.701376) rad
- **axis**: (0, 0, 1)

### Local Transform

$T^{0}_{1}(q_{1}) = T_{fixed} \cdot R_{axis}(q_{1})$ where:

$$
T_{fixed} = \begin{bmatrix}
0.763955 & 0.645269 & 0 & -0.053457 \\
-0.645269 & 0.763955 & 0 & 0.044911 \\
0 & 0 & 1 & -0.022649 \\
0 & 0 & 0 & 1 \\
\end{bmatrix}
$$

$$
R_{axis}(q_{1}) = \begin{bmatrix}
c_{1} & -s_{1} & 0 & 0 \\
s_{1} & c_{1} & 0 & 0 \\
0 & 0 & 1 & 0 \\
0 & 0 & 0 & 1 \\
\end{bmatrix}
$$

---

## shoulder

$L_{1}$ **cylider** -> $L_{2}$ **arm** (continuous)
  Variable: $q_{2}$

- **origin xyz**: (-0.058, 0, 0.204069) m
- **origin rpy**: (-0.256197, 0, 0) rad
- **axis**: (-1, 0, 0)

### Local Transform

$T^{1}_{2}(q_{2}) = T_{fixed} \cdot R_{axis}(q_{2})$ where:

$$
T_{fixed} = \begin{bmatrix}
1 & 0 & 0 & -0.058 \\
0 & 0.967361 & 0.253404 & 0 \\
0 & -0.253404 & 0.967361 & 0.204069 \\
0 & 0 & 0 & 1 \\
\end{bmatrix}
$$

$$
R_{axis}(q_{2}) = \begin{bmatrix}
1 & 0 & 0 & 0 \\
0 & c_{2} & s_{2} & 0 \\
0 & -s_{2} & c_{2} & 0 \\
0 & 0 & 0 & 1 \\
\end{bmatrix}
$$

---

## wristmotion

$L_{2}$ **arm** -> $L_{3}$ **wrist** (revolute)
  Variable: $q_{3}$

- **origin xyz**: (0.057006, -0.216148, 0.176864) m
- **origin rpy**: (-0.478044, 0, 0) rad
- **axis**: (1, 0, 0)
- **limits**: [-1.570796, 0.174533] rad ([-90deg, 10deg])

### Local Transform

$T^{2}_{3}(q_{3}) = T_{fixed} \cdot R_{axis}(q_{3})$ where:

$$
T_{fixed} = \begin{bmatrix}
1 & 0 & 0 & 0.057006 \\
0 & 0.887896 & 0.460044 & -0.216148 \\
0 & -0.460044 & 0.887896 & 0.176864 \\
0 & 0 & 0 & 1 \\
\end{bmatrix}
$$

$$
R_{axis}(q_{3}) = \begin{bmatrix}
1 & 0 & 0 & 0 \\
0 & c_{3} & -s_{3} & 0 \\
0 & s_{3} & c_{3} & 0 \\
0 & 0 & 0 & 1 \\
\end{bmatrix}
$$

---

## joint_gripper1

$L_{3}$ **wrist** -> $L_{4}$ **gripper2** (prismatic)
  Variable: $q_{4}$

- **origin xyz**: (-0.001006, 0.011877, -0.122109) m
- **origin rpy**: (0, 0, 0) rad
- **axis**: (0, -0.996195, -0.087156)
- **limits**: [-0.043, -0.004] m

### Local Transform

$$
T^{3}_{4}(q_{4}) = \begin{bmatrix}
1 & 0 & 0 & -0.001006 \\
0 & 1 & 0 & 0.011877 - q_{4} \\
0 & 0 & 1 & -0.122109 \\
0 & 0 & 0 & 1 \\
\end{bmatrix}
$$

---

## joint_gripper2

$L_{3}$ **wrist** -> $L_{5}$ **gripper1** (prismatic)
  Variable: $q_{5}$

- **origin xyz**: (-0.001006, -0.009043, -0.123939) m
- **origin rpy**: (0, 0, 0) rad
- **axis**: (0, -0.996195, -0.087156)
- **limits**: [0.017, 0.044] m

### Local Transform

$$
T^{3}_{5}(q_{5}) = \begin{bmatrix}
1 & 0 & 0 & -0.001006 \\
0 & 1 & 0 & -0.009043 - q_{5} \\
0 & 0 & 1 & -0.123939 \\
0 & 0 & 0 & 1 \\
\end{bmatrix}
$$

---

## Global Transform Chains

Transform from root $L_0$ to any link, as product of local transforms along the kinematic chain.

$$T^{0}_{2} = T^{0}_{1}(q_{1}) \cdot T^{1}_{2}(q_{2})\quad (L_0 \to L_{2}: \text{arm})$$

$$T^{0}_{3} = T^{0}_{1}(q_{1}) \cdot T^{1}_{2}(q_{2}) \cdot T^{2}_{3}(q_{3})\quad (L_0 \to L_{3}: \text{wrist})$$

$$T^{0}_{4} = T^{0}_{1}(q_{1}) \cdot T^{1}_{2}(q_{2}) \cdot T^{2}_{3}(q_{3}) \cdot T^{3}_{4}(q_{4})\quad (L_0 \to L_{4}: \text{gripper2})$$

$$T^{0}_{5} = T^{0}_{1}(q_{1}) \cdot T^{1}_{2}(q_{2}) \cdot T^{2}_{3}(q_{3}) \cdot T^{3}_{5}(q_{5})\quad (L_0 \to L_{5}: \text{gripper1})$$

