import os
import re
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import ExecuteProcess, TimerAction
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue

def generate_launch_description():
    pkg_name = 'simar_agri_description'
    pkg_dir = get_package_share_directory(pkg_name)
    moveit_pkg_dir = get_package_share_directory('simar_agri_moveit_config')

    urdf_file = os.path.join(pkg_dir, 'urdf', 'simar_agri.urdf')
    target_urdf = os.path.join(pkg_dir, 'urdf', 'target_block.urdf')
    yaml_path = os.path.join(moveit_pkg_dir, 'config', 'ros2_controllers.yaml')
    gazebo_model_path = os.path.join(pkg_dir, '..')

    with open(urdf_file, 'r') as f:
        raw_urdf = f.read()

    # 1. Inject the absolute YAML path
    raw_urdf = raw_urdf.replace('$(find simar_agri_moveit_config)/config/ros2_controllers.yaml', yaml_path)

    # 2. BULLETPROOF SHRINK: Delete bulky XML comments and decorative material blocks
    # This guarantees the URDF drops well below the 4096-byte crash limit
    raw_urdf = re.sub(r'<!--.*?-->', '', raw_urdf, flags=re.DOTALL)
    raw_urdf = re.sub(r'<material name="[^"]+">\s*<color rgba="[^"]+"/>\s*</material>', '', raw_urdf, flags=re.DOTALL)

    # 3. Compress remaining spaces
    minified_urdf = ' '.join(raw_urdf.split())

    robot_description = ParameterValue(minified_urdf, value_type=str)

    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        parameters=[{
            'robot_description': robot_description,
            'use_sim_time': True
        }],
        output='screen',
    )

    gazebo_env = {
        'WAYLAND_DISPLAY': '',
        'LIBGL_ALWAYS_SOFTWARE': '1',
        'MESA_GL_VERSION_OVERRIDE': '3.3',
        'MESA_GLSL_VERSION_OVERRIDE': '330',
        'GAZEBO_MODEL_PATH': gazebo_model_path
    }

    gazebo = ExecuteProcess(
        cmd=['gazebo', '--verbose', '-s', 'libgazebo_ros_init.so', '-s', 'libgazebo_ros_factory.so'],
        output='screen',
        additional_env=gazebo_env
    )

    spawn_entity = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=['-topic', 'robot_description', '-entity', 'simar_agri'],
        output='screen',
    )

    spawn_block = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=['-file', target_urdf, '-entity', 'target_block', '-x', '0.25', '-y', '0.0', '-z', '0.015'],
        output='screen',
    )

    load_joint_state_controller = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['joint_state_broadcaster', '--controller-manager', '/controller_manager'],
        output='screen',
    )

    load_arm_controller = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['arm_controller', '--controller-manager', '/controller_manager'],
        output='screen',
    )

    load_gripper_controller = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['gripper_controller', '--controller-manager', '/controller_manager'],
        output='screen',
    )

    timer_spawners = TimerAction(
        period=5.0,
        actions=[load_joint_state_controller, load_arm_controller, load_gripper_controller]
    )

    return LaunchDescription([
        robot_state_publisher,
        gazebo,
        spawn_entity,
        spawn_block,
        timer_spawners,
    ])
